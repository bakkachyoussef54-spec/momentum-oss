"""Local preview only: synthetic identities, isolated test data."""
import json,urllib.request,urllib.error,uuid
BASE='http://terminal.local:4173/api/data'
A='test-'+str(uuid.uuid4()); B='test-'+str(uuid.uuid4())
def req(body=None,who=A):
 h={'Content-Type':'application/json'}
 if who:h.update({'oai-authenticated-user-id':who,'oai-authenticated-user-email':who+'@example.test'})
 r=urllib.request.Request(BASE,data=json.dumps(body).encode() if body is not None else None,headers=h)
 try:
  with urllib.request.urlopen(r,timeout=10) as x:return x.status,json.load(x)
 except urllib.error.HTTPError as x:return x.code,json.load(x)
def get(id):return next(i for i in req()[1]['items'] if i['id']==id)
def create(kind,data):
 status,out=req({'kind':kind,'data':data});assert status==200,(status,out);return get(out['id'])
def update(i,**changes):return req({'kind':i['kind'],'id':i['id'],'version':i['version'],'data':dict(i['data'],**changes)})
try:
 assert req(who=None)[0]==401
 g=create('goal',{'title':'Test goal','start':'2026-10-01','due':'2026-12-01','target':10,'current':0})
 assert not req(who=B)[1]['items']
 assert req({'kind':'goal','id':g['id'],'version':1,'data':g['data']},B)[0]==404
 assert req({'kind':'task','data':{'title':'Bad','date':'2026-10-27','due':'2026-10-27','goalId':g['id']}},B)[0]==400
 assert update(g,current=2)[0]==200
 assert update(g,current=3)[0]==409
 t=create('task',{'title':'Recurring','date':'2026-10-27','due':'2026-10-27','repeat':'Daily','goalId':g['id']})
 assert update(t,status='Completed')[0]==200
 assert len([i for i in req()[1]['items'] if i['kind']=='task'])==2
 t=get(t['id']);assert update(t,status='To Do')[0]==200
 t=get(t['id']);assert update(t,status='Completed')[0]==200
 assert len([i for i in req()[1]['items'] if i['kind']=='task'])==2
 h=create('habit',{'title':'Habit','start':'2026-10-01','days':[0,1,2,3,4,5,6]})
 c=create('checkin',{'habitId':h['id'],'date':'2026-10-26','value':1})
 assert req({'kind':'checkin','data':c['data']})[0]==409
 s=create('session',{'title':'Focus','mode':'Pomodoro','duration':1500,'elapsed':0,'startedAt':None,'status':'running','date':'2026-10-27'})
 assert req({'kind':'session','data':s['data']})[0]==409
 assert update(s,status='paused')[0]==200
 s=get(s['id']);assert s['data']['startedAt'] is None
 assert update(s,status='running')[0]==200
 s=get(s['id']);assert update(s,status='saved')[0]==200
 assert update(get(s['id']),status='running')[0]==400
 assert req({'action':'delete','id':h['id'],'version':h['version']})[0]==200
 assert not any(i['kind']=='checkin' for i in req()[1]['items'])
 print('PASS: auth rejection, owner isolation, cross-owner relations, CRUD persistence, conflicts, recurrence deduplication, check-in uniqueness, single active timer, pause/resume/save, cascade deletion.')
finally:
 for who in [A,B]:
  try:req({'action':'deleteAll','confirm':'DELETE'},who)
  except urllib.error.URLError:pass
