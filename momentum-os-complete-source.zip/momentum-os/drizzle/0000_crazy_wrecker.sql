CREATE TABLE `records` (
	`id` text PRIMARY KEY NOT NULL,
	`owner` text NOT NULL,
	`kind` text NOT NULL,
	`data` text NOT NULL,
	`version` integer DEFAULT 1 NOT NULL,
	`created_at` text NOT NULL,
	`updated_at` text NOT NULL,
	`natural_key` text
);
--> statement-breakpoint
CREATE INDEX `owner_kind` ON `records` (`owner`,`kind`);--> statement-breakpoint
CREATE UNIQUE INDEX `owner_natural_key` ON `records` (`owner`,`natural_key`);