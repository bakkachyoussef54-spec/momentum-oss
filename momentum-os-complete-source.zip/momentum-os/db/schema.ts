import { sqliteTable, text, integer, uniqueIndex, index } from 'drizzle-orm/sqlite-core';
// Versioned, validated domain documents. Relations are checked against the authenticated owner.
export const records = sqliteTable('records', {
 id: text('id').primaryKey(), owner: text('owner').notNull(), kind: text('kind').notNull(),
 data: text('data').notNull(), version: integer('version').notNull().default(1),
 createdAt: text('created_at').notNull(), updatedAt: text('updated_at').notNull(),
 naturalKey: text('natural_key'),
}, t=>[index('owner_kind').on(t.owner,t.kind),uniqueIndex('owner_natural_key').on(t.owner,t.naturalKey)]);
