import type { Metadata } from 'next';
import './globals.css';
export const metadata:Metadata={title:'Momentum OS — Make progress intentional',description:'Your goals, daily actions and focused work in one private workspace.'};
export default function Layout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}
