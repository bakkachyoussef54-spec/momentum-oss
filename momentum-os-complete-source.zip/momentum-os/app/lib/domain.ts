import { z } from 'zod';
const date=z.string().regex(/^\d{4}-\d{2}-\d{2}$/).refine(s=>{const d=new Date(s+'T12:00:00Z');return !isNaN(+d)&&d.toISOString().slice(0,10)===s},'Invalid date');
const title=z.string().trim().min(1).max(160), notes=z.string().max(6000).default('');
const number=z.number().finite().min(0).max(1e12);
const ref=z.string().max(80).default('');
export const schemas={
 goal:z.object({title,description:notes,category:z.string().max(50).default('Personal'),start:date,due:date,target:number.refine(n=>n>0),current:number,unit:z.string().max(30).default('steps'),type:z.enum(['Numeric','Monetary','Percentage','Completion','Milestones']).default('Numeric'),status:z.enum(['Not Started','In Progress','Completed','Paused','Archived']).default('In Progress'),priority:z.enum(['High','Medium','Low']).default('Medium')}).refine(d=>d.due>=d.start,'Target date must follow start date'),
 milestone:z.object({title,goalId:ref,done:z.boolean().default(false)}),
 task:z.object({title,description:notes,date, time:z.string().regex(/^$|^([01]\d|2[0-3]):[0-5]\d$/).default(''),due:date,priority:z.enum(['Critical','High','Medium','Low']).default('Medium'),status:z.enum(['To Do','In Progress','Completed','Cancelled']).default('To Do'),goalId:ref,estimate:z.number().int().min(0).max(1440).default(25),category:z.string().max(50).default('Personal'),top:z.boolean().default(false),repeat:z.enum(['None','Daily','Weekdays','Weekly']).default('None'),parentId:ref,completedAt:z.string().max(40).default(''),order:z.number().finite().default(0)}),
 habit:z.object({title,description:notes,days:z.array(z.number().int().min(0).max(6)).min(1).max(7),start:date,color:z.enum(['purple','green','orange','blue']).default('purple'),target:z.number().min(1).max(10000).default(1)}),
 checkin:z.object({habitId:ref,date,value:number}),
 cycle:z.object({title,start:date,goalIds:z.array(z.string()).max(3)}),
 review:z.object({date,wins:notes,obstacles:notes,next:notes}),
 income:z.object({title,amount:number.refine(n=>n>0),currency:z.enum(['USD','MAD','EUR','GBP']),date,category:z.string().max(60).default('Freelance')}),
 outcome:z.object({title,value:number,unit:z.string().max(30),date}),
 session:z.object({title,taskId:ref,goalId:ref,mode:z.enum(['Pomodoro','Short Break','Long Break','Custom','Stopwatch']),duration:z.number().int().min(60).max(86400),elapsed:z.number().min(0).max(86400),startedAt:z.number().nullable(),status:z.enum(['running','paused','saved']),date}),
 settings:z.object({name:z.string().trim().min(1).max(80),timezone:z.string().refine(s=>{try{Intl.DateTimeFormat('en',{timeZone:s});return true}catch{return false}},'Invalid timezone'),theme:z.enum(['dark','light']),currency:z.enum(['USD','MAD','EUR','GBP']),incomeTarget:number,weekStart:z.enum(['Monday','Sunday']),onboarded:z.boolean(),widgets:z.array(z.string()).max(10).default(['tasks','goals','habits']),reminders:z.boolean().default(false)}),
};
// Values are validated by the kind-specific Zod schema before persistence.
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export type Fields = Record<string, any>;
export type Kind=keyof typeof schemas;
export type Item={id:string;kind:Kind;data:Fields;version:number;createdAt:string;updatedAt:string};
export function localDate(timezone='UTC',when=new Date()){return new Intl.DateTimeFormat('en-CA',{timeZone:timezone,year:'numeric',month:'2-digit',day:'2-digit'}).format(when)}
export function addDays(date:string,n:number){const d=new Date(date+'T12:00:00Z');d.setUTCDate(d.getUTCDate()+n);return d.toISOString().slice(0,10)}
export function daysBetween(a:string,b:string){return Math.round((+new Date(b+'T12:00:00Z')-+new Date(a+'T12:00:00Z'))/86400000)}
export function weekStart(date:string,sunday=false){const day=new Date(date+'T12:00:00Z').getUTCDay();return addDays(date,-((day+(sunday?0:6))%7))}
export function execution(tasks:Item[],start:string,end:string){const eligible=tasks.filter(t=>t.data.date>=start&&t.data.date<=end&&t.data.status!=='Cancelled');return {total:eligible.length,done:eligible.filter(t=>t.data.status==='Completed').length,rate:eligible.length?Math.round(eligible.filter(t=>t.data.status==='Completed').length/eligible.length*100):0}}
export function progress(goal:Item,items:Item[]){if(goal.data.type==='Milestones'){const m=items.filter(i=>i.kind==='milestone'&&i.data.goalId===goal.id);return m.length?Math.round(m.filter(i=>i.data.done).length/m.length*100):0}return Math.min(100,Math.max(0,Math.round(goal.data.current/goal.data.target*100)))}
export function streak(habit:Item,items:Item[],today:string){let current=0,longest=0,run=0;const hits=new Set(items.filter(i=>i.kind==='checkin'&&i.data.habitId===habit.id&&i.data.value>=habit.data.target).map(i=>i.data.date));for(let d=habit.data.start;d<=today;d=addDays(d,1)){if(!habit.data.days.includes(new Date(d+'T12:00:00Z').getUTCDay()))continue;if(hits.has(d)){run++;longest=Math.max(longest,run)}else if(d!==today)run=0}current=run;return {current,longest}}
export function elapsedSeconds(d:Fields,now:number){const v=d.elapsed+(d.status==='running'&&d.startedAt?Math.max(0,(now-d.startedAt)/1000):0);return Math.floor(Math.min(d.mode==='Stopwatch'?86400:d.duration,v))}
export function habitConsistency(habit:Item,items:Item[],start:string,end:string){let total=0,done=0;const hits=new Set(items.filter(i=>i.kind==='checkin'&&i.data.habitId===habit.id&&i.data.value>=habit.data.target).map(i=>i.data.date));for(let d=start;d<=end;d=addDays(d,1)){if(d<habit.data.start||!habit.data.days.includes(new Date(d+'T12:00:00Z').getUTCDay()))continue;total++;if(hits.has(d))done++}return total?Math.round(done/total*100):0}
