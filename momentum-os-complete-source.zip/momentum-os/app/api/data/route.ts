import { env } from 'cloudflare:workers';
import { getChatGPTUser } from '../../chatgpt-auth';
import { schemas, type Kind, type Item, type Fields, localDate, addDays, elapsedSeconds } from '../../lib/domain';
export const dynamic='force-dynamic';
const response=(v:unknown,status=200)=>Response.json(v,{status,headers:{'Cache-Control':'no-store'}});
function row(r:Record<string,unknown>):Item{return {id:r.id as string,kind:r.kind as Kind,data:JSON.parse(r.data as string),version:r.version as number,createdAt:r.created_at as string,updatedAt:r.updated_at as string}}
export async function GET(){const user=await getChatGPTUser();if(!user)return response({error:'Sign in to load your workspace.'},401);try{const db=env.DB!;const rows=await db.prepare('SELECT * FROM records WHERE owner=? ORDER BY created_at').bind(user.userId).all();return response({items:rows.results.map(row),user:{name:user.displayName,email:user.email}})}catch{return response({error:'Could not load data. Please retry.'},503)}}
export async function POST(request:Request){
 const user=await getChatGPTUser();if(!user)return response({error:'Please sign in again.'},401);
 const origin=request.headers.get('origin');if(origin&&origin!==new URL(request.url).origin)return response({error:'Invalid request origin.'},403);
 if(Number(request.headers.get('content-length')||0)>40000)return response({error:'Request too large.'},413);
 try{
 const text=await request.text();if(text.length>40000)return response({error:'Request too large.'},413);const b=JSON.parse(text);const db=env.DB!;const owner=user.userId;
 const all=await db.prepare('SELECT * FROM records WHERE owner=?').bind(owner).all();const items=all.results.map(row);const existing=items.find(i=>i.id===b.id);
 if(b.action==='deleteAll'){if(b.confirm!=='DELETE')return response({error:'Confirmation required.'},400);await db.prepare('DELETE FROM records WHERE owner=?').bind(owner).run();return response({ok:true})}
 if(b.action==='delete'){
 if(!existing)return response({error:'Record not found.'},404);if(existing.version!==b.version)return response({error:'This record changed. Reload before deleting.'},409);
 const children=items.filter(i=>(existing.kind==='habit'&&i.kind==='checkin'&&i.data.habitId===existing.id)||(existing.kind==='goal'&&i.kind==='milestone'&&i.data.goalId===existing.id)||(existing.kind==='task'&&i.kind==='task'&&i.data.parentId===existing.id));
 const stmts=[db.prepare('DELETE FROM records WHERE owner=? AND id=? AND version=?').bind(owner,existing.id,b.version),...children.map(i=>db.prepare('DELETE FROM records WHERE owner=? AND id=?').bind(owner,i.id))];
 for(const i of items){if(children.some(c=>c.id===i.id)||i.id===existing.id)continue;const d={...i.data};let changed=false;for(const key of ['goalId','taskId'])if(d[key]===existing.id){d[key]='';changed=true}if(Array.isArray(d.goalIds)&&d.goalIds.includes(existing.id)){d.goalIds=d.goalIds.filter((id:string)=>id!==existing.id);changed=true}if(changed)stmts.push(db.prepare('UPDATE records SET data=?,version=version+1 WHERE owner=? AND id=?').bind(JSON.stringify(d),owner,i.id))}
 await db.batch(stmts);return response({ok:true})}
 const kind=b.kind as Kind;if(!(kind in schemas))return response({error:'Unknown record type.'},400);
 const parsed=schemas[kind].safeParse(b.data);if(!parsed.success)return response({error:parsed.error.issues.map(i=>i.message).join(', ')},400);
 const data=parsed.data as Fields;const now=new Date().toISOString();const settings=items.find(i=>i.kind==='settings');const today=localDate(settings?.data.timezone||'UTC');
 if(b.id&&!existing)return response({error:'Record not found.'},404);if(existing&&(existing.kind!==kind||existing.version!==b.version))return response({error:'Another tab updated this record. Reload and try again.'},409);
 for(const [key,expected] of [['goalId','goal'],['taskId','task'],['habitId','habit'],['parentId','task']])if(data[key]&&!items.some(i=>i.id===data[key]&&i.kind===expected))return response({error:'Linked record does not belong to your workspace.'},400);
 if(kind==='cycle'&&data.goalIds.some((id:string)=>!items.some(i=>i.id===id&&i.kind==='goal')))return response({error:'Invalid cycle goal.'},400);
 if(kind==='checkin'){const habit=items.find(i=>i.id===data.habitId)!;if(data.date>today||data.date<habit.data.start||!habit.data.days.includes(new Date(data.date+'T12:00:00Z').getUTCDay()))return response({error:'Choose a scheduled day between the habit start and today.'},400)}
 if(kind==='task'){
 if(data.top&&items.filter(i=>i.kind==='task'&&i.data.date===data.date&&i.data.top&&i.id!==existing?.id).length>=3)return response({error:'Choose up to three priorities per day.'},400);
 if(data.parentId===existing?.id)return response({error:'A task cannot be its own parent.'},400);
 if(data.parentId&&items.find(i=>i.id===data.parentId)?.data.parentId)return response({error:'Subtasks support one level.'},400);
 data.completedAt=data.status==='Completed'?(existing?.data.completedAt||now):'';
 }
 let naturalKey:string|null=kind==='settings'?'settings':kind==='checkin'?`checkin:${data.habitId}:${data.date}`:kind==='review'?`review:${data.date}`:null;
 if(kind==='session'){
 if(!existing){data.elapsed=0;data.startedAt=Date.now();data.status='running'}else{if(existing.data.status==='saved')return response({error:'Saved sessions cannot be restarted.'},400);data.elapsed=elapsedSeconds(existing.data,Date.now());data.startedAt=data.status==='running'?Date.now():null;data.duration=existing.data.duration;data.mode=existing.data.mode}
 if(data.status!=='saved')naturalKey='active-session';
 }
 if(!existing&&naturalKey&&items.some(i=>i.kind===kind&&(kind==='settings'||(kind==='checkin'&&i.data.habitId===data.habitId&&i.data.date===data.date)||(kind==='review'&&i.data.date===data.date)||(kind==='session'&&i.data.status!=='saved'))))return response({error:'This record already exists. Reload to see the latest version.'},409);
 const id=existing?.id||crypto.randomUUID();
 if(existing){const r=await db.prepare('UPDATE records SET data=?,natural_key=?,version=version+1,updated_at=? WHERE owner=? AND id=? AND version=?').bind(JSON.stringify(data),naturalKey,now,owner,id,b.version).run();if(!r.meta.changes)return response({error:'Record changed. Reload and try again.'},409)}else await db.prepare('INSERT INTO records (id,owner,kind,data,natural_key,version,created_at,updated_at) VALUES(?,?,?,?,?,1,?,?)').bind(id,owner,kind,JSON.stringify(data),naturalKey,now,now).run();
 if(kind==='task'&&data.status==='Completed'&&data.repeat!=='None'&&existing?.data.status!=='Completed'){
 let next=addDays(data.date,data.repeat==='Weekly'?7:1);if(data.repeat==='Weekdays')while([0,6].includes(new Date(next+'T12:00:00Z').getUTCDay()))next=addDays(next,1);
 const nextData={...data,date:next,due:next,status:'To Do',completedAt:'',top:false};await db.prepare('INSERT OR IGNORE INTO records (id,owner,kind,data,natural_key,version,created_at,updated_at) VALUES(?,?,?,?,?,1,?,?)').bind(crypto.randomUUID(),owner,'task',JSON.stringify(nextData),`repeat:${id}:${next}`,now,now).run();
 }
 return response({ok:true,id});
 }catch(e){console.error('Workspace operation failed',e instanceof Error?e.name:'unknown');return response({error:'Could not save this change. Reload and try again.'},500)}
}
